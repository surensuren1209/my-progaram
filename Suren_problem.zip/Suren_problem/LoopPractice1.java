package looppractice1;

public class LoopPractice1 {

    public static void main(String[] args) {
        //for(int i=0;i<=10;i++)
        //for(int i=0;i>0;i--)
        
        //int i=0;
        //for(System.out.println("Hi");i<=10;i++)
        //for(;;)
        
        for(int i=0,j=1;i<=10;i++,j=j*2)
        {
            System.out.println(i);
        }
    }
    
}
