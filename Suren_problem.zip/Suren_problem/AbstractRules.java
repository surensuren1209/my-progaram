package abstractrules;

abstract class Super
{
    abstract public void meth1();
}

class Sub extends Super
{
    public void meth1()
    {
        
    }
}

public class AbstractRules {

    public static void main(String[] args) {
        
        Super s;
        
        
    }
    
}
