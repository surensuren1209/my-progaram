package variablenames;

public class VariableNames {

    public static void main(String[] args) {
        //int x;
        //int roll_number$student;
        //int _x;
        
        //int rollNumberOfStudent;
        //float averageMarksOfClass;
        
    }
    
}
