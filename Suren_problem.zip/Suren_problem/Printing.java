package printing;

import java.util.*;

public class Printing {
    public static void main(String[] args) {
        
        /*int a=10;
        float b=12.55f;
        char c='A';
        String str="Hello";
        
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(str);*/
        
        
        int x=10,y=20;
        System.out.println(x+y);
        System.out.println("Number is " +y);
        System.out.println(x+y+" sum");
        System.out.println("sum "+(x+y));
        System.out.println("sum of "+x+" and "+y+" is "+(x+y));
    }
    
}
