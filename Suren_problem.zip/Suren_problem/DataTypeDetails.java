package datatypedetails;

import java.awt.*;
import javax.swing.*;
import java.lang.*;


public class DataTypeDetails {

    public static void main(String[] args) {
        int x=-5;//5
        
        System.out.println(Integer.toBinaryString(x));
    }
    
}
