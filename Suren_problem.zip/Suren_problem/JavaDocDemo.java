/** @author Abdul Bari
 * 
 **/
package javadocdemo;

public class JavaDocDemo 
{
    public static void main(String[] args) 
    {
        
    }   
}
